@file:JsQualifier("firebase.app")
@file:Suppress("INTERFACE_WITH_SUPERCLASS", "OVERRIDING_FINAL_MEMBER", "RETURN_TYPE_MISMATCH_ON_OVERRIDE", "CONFLICTING_OVERLOADS", "EXTERNAL_DELEGATION")
package firebase.app

import kotlin.js.*
import kotlin.js.Json
import org.khronos.webgl.*
import org.w3c.dom.*
import org.w3c.dom.events.*
import org.w3c.dom.parsing.*
import org.w3c.dom.svg.*
import org.w3c.dom.url.*
import org.w3c.fetch.*
import org.w3c.files.*
import org.w3c.notifications.*
import org.w3c.performance.*
import org.w3c.workers.*
import org.w3c.xhr.*
import firebase.auth.Auth
import firebase.database.Database
import firebase.installations.Installations
import firebase.messaging.Messaging
import firebase.storage.Storage
import firebase.firestore.Firestore
import firebase.functions.Functions
import firebase.performance.Performance
import firebase.remoteConfig.RemoteConfig
import firebase.analytics.Analytics

external interface App {
    fun auth(): Auth
    fun database(url: String? = definedExternally): Database
    fun delete(): Promise<Any>
    fun installations(): Installations
    fun messaging(): Messaging
    var name: String
    var options: Any
    fun storage(url: String? = definedExternally): Storage
    fun firestore(): Firestore
    fun functions(region: String? = definedExternally): Functions
    fun performance(): Performance
    fun remoteConfig(): RemoteConfig
    fun analytics(): Analytics
}