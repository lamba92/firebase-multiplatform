@file:JsQualifier("firebase.messaging")
@file:Suppress("INTERFACE_WITH_SUPERCLASS", "OVERRIDING_FINAL_MEMBER", "RETURN_TYPE_MISMATCH_ON_OVERRIDE", "CONFLICTING_OVERLOADS", "EXTERNAL_DELEGATION")
package firebase.messaging

import kotlin.js.*
import kotlin.js.Json
import org.khronos.webgl.*
import org.w3c.dom.*
import org.w3c.dom.events.*
import org.w3c.dom.parsing.*
import org.w3c.dom.svg.*
import org.w3c.dom.url.*
import org.w3c.fetch.*
import org.w3c.files.*
import org.w3c.notifications.*
import org.w3c.performance.*
import org.w3c.workers.*
import org.w3c.xhr.*
import firebase.NextFn
import firebase.ErrorFn
import firebase.CompleteFn
import firebase.Unsubscribe
import firebase.Observer

external interface Messaging {
    fun deleteToken(token: String): Promise<Boolean>
    fun getToken(): Promise<String>
    fun <E> onMessage(nextOrObserver: NextFn<Any>, error: ErrorFn<E>? = definedExternally, completed: CompleteFn? = definedExternally): Unsubscribe
    fun <E> onMessage(nextOrObserver: Observer<Any, Error>, error: ErrorFn<E>? = definedExternally, completed: CompleteFn? = definedExternally): Unsubscribe
    fun <E> onTokenRefresh(nextOrObserver: NextFn<Any>, error: ErrorFn<E>? = definedExternally, completed: CompleteFn? = definedExternally): Unsubscribe
    fun <E> onTokenRefresh(nextOrObserver: Observer<Any, Error>, error: ErrorFn<E>? = definedExternally, completed: CompleteFn? = definedExternally): Unsubscribe
    fun requestPermission(): Promise<Unit>
    fun setBackgroundMessageHandler(callback: (payload: Any) -> dynamic)
    fun useServiceWorker(registration: ServiceWorkerRegistration)
    fun usePublicVapidKey(b64PublicKey: String)
}

external fun isSupported(): Boolean